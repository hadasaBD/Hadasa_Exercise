package com.company;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.InvalidParameterException;

public class Main {

    public static void main(String[] args) {
	// write your code her
       /* write an encryption program and the program should work in the next manner:
        1 Should allow the user to choose between Encryption and Decryption (build a convenient menu to the users)
        2 After that:
        a. Inputs the path to the source file from the user
        b. prints encryption/decryption simulation of file $file$
        i. if path isn't a file or not exists prompt error and asks for a path again
        ii. no need to read the file for now.
        */
       /*
       לכתוב תוכנת הצפנה התוכנית צריכה לעבוד באופן הבא:
       1 צריך לאפשר למשתמש לבחור בין הצפנה ופענוח (לבנות תפריט נוח למשתמשים)
       2 לאחר מכן:
                                                             א. תשומות את הנתיב אל קובץ המקור מהמשתמש
                                    ב. הדפסים הצפנה / סימולציה הפענוח של הקובץ $ $ קובץ
                        אם נתיב אינו קובץ או לא קיים שגיאה פקודה ומבקש נתיב שוב
              ii. לא צריך לקרוא את הקובץ לעת עתה.
        */

    Menu menu = new Menu();

    }

}
