package com.company;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Created by hackeru on 3/14/2017.
 */
class MenuTest {
    @BeforeAll
    static  void beforeAll(){
        System.out.println("in beforeAll() of menu");
    }
    @AfterAll
    static void afterAll(){
        System.out.println("in afterAll() of menu");
    }
    @BeforeEach
    void setUp() {

    }

    @AfterEach
    void tearDown() {

    }

    @Test
    void mainMenu() {

    }

    @Test
    void readInput() {

    }

    @Test
    void printMenu() {

    }

}